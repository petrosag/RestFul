/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rest.dao;

import com.mycompany.rest.dao.Students;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import static org.eclipse.persistence.config.ExclusiveConnectionMode.Transactional;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author w207768658
 */
@Component
public class StudentDAO {
    // Injected database connection:

    @PersistenceContext()
    private EntityManager em;

    // Stores a new guest:
    @Transactional
    public void persist(Students student) {
        em.persist(student);
    }

    // Retrieves all the guests:
    public List<Students> getAllStudents() {

        TypedQuery<Students> query = em.createQuery("SELECT s FROM Students s ORDER BY s.id", Students.class);
        return query.getResultList();

    }
}
